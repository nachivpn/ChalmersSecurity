# FlowIT

FlowIT is based on the dynamic monitor JSFlow (v1.1.0). FlowIT parameterizes JSFlow 
with a set of blacklisted domains `blackValues` and an action set `actionSet`, and 
extends the syntax with several constructs for sink declarations, action skipping, 
or URL upload and image creation. For a detailed description of the extension, 
refer to EXTENSION.md.

## Installation

Install the dependencies with `npm install`. 

## Execution

The monitor evaluates the code in `js_code.js` by executing the following command:
`./jsflow js_code.js`

## Presence-sensitivity

- Presence-sensitive code is executed with flag `-sensitive`:
`./jsflow -sensitive presence_sensitive_code.js`

- No labels should be used in the code marked as presence-sensitive.

## Contributors

* Iulia Bastys
* Musard Balliu
* Andrei Sabelfeld


# JSFlow 

[![Build Status](https://semaphoreci.com/api/v1/projects/ec57d3d7-dc77-4698-8159-7ad097cc01e2/700294/badge.svg)](https://semaphoreci.com/lbello/jsflow)
JSFlow is an information flow aware JavaScript interpreter written in JavaScript.

## JSFlow contributors

* Daniel Hedin
* Alexander Sjösten
* Andrei Sabelfeld 

Former contributors:

* Arnar Birgisson
* Luciano Bello






