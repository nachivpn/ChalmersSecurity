// Filter code in Example 6.4
// Maker: ---
// Link : ---

// Trigger: ---
// Action: ---

// Policy/Presence: Confidentiality of trigger data / No

logo = imgl("www.attacker.com");
sink('Sink', '', logo);
