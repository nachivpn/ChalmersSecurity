// Filter code in Example 6.8
// Maker: ---
// Link : ---

// Trigger: ---
// Action: ---

// Policy/Presence: Confidentiality of trigger data / Yes

l = true;
sink('Sink', '', imgh('w'));
if (l) {
	sink('Sink', '', imgh('source'));
}
